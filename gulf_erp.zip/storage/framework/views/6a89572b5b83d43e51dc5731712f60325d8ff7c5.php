    <!--**********************************
                Sidebar start
    ***********************************-->
    <div class="deznav scrollbar">
        
            <div class="main-profile">
                <div class="image-bx">
                    <img src="<?php echo e(asset('public')); ?>/images/profile/<?php echo e(Auth::user()->profile_photo_path); ?>" alt="">
                    <a href="javascript:void(0);"><i class="fa fa-cog" aria-hidden="true"></i></a>
                </div>
                <h5 class="name"><?php echo e(Auth::user()->name); ?></h5>
                <p class="email"><a href="mailto:<nowiki><?php echo e(Auth::user()->email); ?>">[<?php echo e(Auth::user()->email); ?>]</a></p>
            </div>
            <ul class="metismenu" id="menu">
                <li class="nav-label first">Main Menu</li>
                <li><a href="<?php echo e(route('dashboard')); ?>" class="ai-icon" aria-expanded="false">
                        <i class="flaticon-144-layout"></i>
                        <span class="nav-text">Dashboard</span>
                    </a>
                </li>
                <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
                        <i class="flaticon-152-followers"></i>
                        <span class="nav-text">HR & Admin</span>
                    </a>
                    <ul aria-expanded="false">
                        <li><a href="<?php echo e(route('info_employee.index')); ?>">Employee Registration </a></li>
                        
                        
                        <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">Leave</a>
                            <ul aria-expanded="false">
                                <li><a href="<?php echo e(route('leave_self.create')); ?>">Self Leave</a></li>
                                <li><a href="<?php echo e(route('emergency_leave.create')); ?>">Emergency Leave</a></li>
                                <li><a href="<?php echo e(route('dept_approve_list.create')); ?>">Dept. Approve</a></li>
                                <li><a href="<?php echo e(route('hr_approve_list.create')); ?>">HR Approve</a></li>
                            </ul>
                        </li>
                        <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">Attendance</a>
                            <ul aria-expanded="false">
                                <li><a href="<?php echo e(route('manual_attendances.index')); ?>">Attendance List</a></li>
                                <li><a href="<?php echo e(route('manual_attendances.create')); ?>">Manual Attendance</a></li>
                                <li><a href="<?php echo e(route('attendance_approve.create')); ?>">Attendance Approve</a></li>
                                <li><a href="<?php echo e(route('attendance.import')); ?>">Upload Attendance</a></li>
                            </ul>
                        </li>
                        <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">Salary</a>
                            <ul aria-expanded="false">
                                <li><a href="#">Process Salary</a></li>
                                <li><a href="#">Pay Slip</a></li>
                                <li><a href="#">Salary Sheet</a></li>
                            </ul>
                        </li>
                        <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">Data Setting</a>
                            <ul aria-expanded="false">
                                <li><a href="<?php echo e(route('mast_department.index')); ?>">Depertment</a></li>
                                <li><a href="<?php echo e(route('mast_designation.index')); ?>">Desgination</a></li>
                                <li><a href="<?php echo e(route('mast_leave.index')); ?>">Leave Type</a></li>
                                <li><a href="<?php echo e(route('must_employee_category.index')); ?>">Employee Category</a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
                        <i class="flaticon-381-home"></i>
                        <span class="nav-text">Inventory</span>
                    </a>
                    <ul aria-expanded="false">
                        <li><a href="#">GRN (Warehouse)</a></li>
                        <li><a href="#">Purchase</a></li>
                        <li><a href="#">Stock Delivery</a></li>
                        <li><a href="#">Stock Update</a></li>
                        <li><a href="#">Stock Possition</a></li>
                        <li><a href="#">Reports</a></li>
                    </ul>
                </li>
                <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
                        <i class="flaticon-381-layer-1"></i>
                        <span class="nav-text">Sales</span>
                    </a>
                    <ul aria-expanded="false">
                        <li><a href="#">Importer Sales</a></li>
                        <li><a href="#">Distributer Sales</a></li>
                        <li><a href="#">Reseller Sales</a></li>
                        <li><a href="#">Delivery</a></li>
                        <li><a href="#">Product Receive</a></li>
                        <li><a href="#">Product Return</a></li>
                        <li><a href="#">Warrenty & Service</a></li>
                        <li><a href="#">Reports</a></li>
                        <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">Data Setting</a>
                            <ul aria-expanded="false">
                                <li><a href="#">Distributer Details</a></li>
                                <li><a href="#">Reseller Details</a></li>
                                <li><a href="#">Reseller Sales</a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
                        <i class="flaticon-149-diagram"></i>
                        <span class="nav-text">Warrenty & Service</span>
                    </a>
                    <ul aria-expanded="false">
                        <li><a href="#">Complaint / Issue</a></li>
                        <li><a href="#">Prepare Job Card</a></li>
                        <li><a href="#">Tachnician Movement</a></li>
                        <li><a href="#">Spare Parts Requsition</a></li>
                        <li><a href="#">Tools Requsition</a></li>
                        <li><a href="#">Tools Requsition</a></li>
                    </ul>
                </li>
                <li class="nav-label">Apps</li>
                <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
                        <i class="flaticon-077-menu-1"></i>
                        <span class="nav-text">Apps</span>
                    </a>
                    <ul aria-expanded="false">
                        <li><a href="#">Profile</a></li>
                        <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">Shop</a>
                            <ul aria-expanded="false">
                                <li><a href="#">Product Grid</a></li>
                                <li><a href="#">Product List</a></li>
                                <li><a href="#">Product Details</a></li>
                            </ul>
                        </li>
                    </ul>
                    
                </li>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('Setting access')): ?>
                <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
                        <i class="flaticon-381-settings-2"></i>
                        <span class="nav-text">Setting</span>
                    </a>
                    <ul aria-expanded="false">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('Role access','Role add','Role edit','Role delete')): ?>
                            <li><a href="<?php echo e(route('roles.index')); ?>">Role</a></li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('User access','User add','User edit','User delete')): ?>
                        <li><a href="<?php echo e(Route('users.index')); ?>">User</a></li>
                        <?php endif; ?>
                    </ul>
                </li>
                <?php endif; ?>
            </ul>
            <div class="copyright">
                <p><strong>Gulf ERP Admin Dashboard</strong> © 2023 All Rights Reserved</p>
                <p class="fs-12">Made with <span class="heart"></span> by Icon ISL</p>
            </div>
        
    </div>
    <!--**********************************
                Sidebar end
    ***********************************--><?php /**PATH C:\xampp\htdocs\gulf_erps\resources\views/layouts/partial/sidebar.blade.php ENDPATH**/ ?>