<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- Leave Application Modal -->
    <div class="modal fade bd-example-modal-lg_form" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <?php if(session()->has('success')): ?>
                    <strong class="text-success"><?php echo e(session()->get('success')); ?></strong>
                <?php endif; ?>
                <form class="form-valide" data-action="<?php echo e(route('leave_application.store')); ?>" method="POST" enctype="multipart/form-data" id="add-user-form">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h5 class="modal-title">Emergency Leave Application</h5>
                        <button type="button" class="close" data-dismiss="modal"><span>&times;</span>
                        </button>
                    </div>
                    <div class="modal-body row">
                        <div class="col-lg-6">
                            <div class="form-group row">
                                <label class="col-lg-5 col-form-label">Employee Name
                                    <span class="text-danger">*</span>
                                </label>
                                <div class="col-lg-7">
                                    <select class="form-control dropdwon_select" id="employeeName" name="emp_id">
                                        <option selected>Select</option>
                                        <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($row->id); ?>"><?php echo e($row->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group row">
                                <label class="col-lg-5 col-form-label">Employee Code</label>
                                <div class="col-lg-7">
                                    <label class="col-lg-7 col-form-label" id="employeeCode">GULF-XXXX</label>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group row">
                                <label class="col-lg-5 col-form-label">Start Date
                                    <span class="text-danger">*</span>
                                </label>
                                <div class="col-lg-7">
                                    <input type="date" class="form-control <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="start_date" placeholder="Enter Date.." value="<?php echo e(old('start_date')); ?>" id="start_date">
                                    <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group row">
                                <label class="col-lg-5 col-form-label">End Date
                                    <span class="text-danger">*</span>
                                </label>
                                <div class="col-lg-7">
                                    <input type="date" class="form-control <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="end_date" value="<?php echo e(old('end_date')); ?>" id="end_date">
                                    <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group row">
                                <label class="col-lg-5 col-form-label">Leave Type
                                    <span class="text-danger">*</span>
                                </label>
                                <div class="col-lg-7">
                                    <select class="form-control default-select" id="leave_type" name="mast_leave_id">
                                        <option disabled selected>Please select</option>
                                        <?php $__currentLoopData = $leave_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($row->id); ?>"><?php echo e($row->leave_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select> 
                                    <?php $__errorArgs = ['leave_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group row">
                                <label class="col-lg-5 col-form-label">Contact Number
                                    <span class="text-danger">*</span>
                                </label>
                                <div class="col-lg-7">
                                    <input type="number" class="form-control <?php $__errorArgs = ['leave_contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="leave_contact" value="<?php echo e(old('leave_contact')); ?>">
                                    <?php $__errorArgs = ['leave_contact'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group row">
                                <label class="col-lg-5 col-form-label">Leave Location</label>
                                <div class="col-lg-7">
                                    <input type="text" class="form-control <?php $__errorArgs = ['leave_location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="leave_location" placeholder="Enter location.." value="<?php echo e(old('location')); ?>">
                                    <?php $__errorArgs = ['start_dates'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group row">
                                <label class="col-lg-5 col-form-label">Leave Purpose</label>
                                <div class="col-lg-7">
                                    <input type="text" class="form-control <?php $__errorArgs = ['purpose'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="purpose" placeholder="Enter purpose.." value="<?php echo e(old('purpose')); ?>">
                                    <?php $__errorArgs = ['start_dates'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger light" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Leave Application List<span class="bg-blue-500 text-white rounded px-1 text-xs py-0.5"></span></h4>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Role create')): ?>
                    <a href="#" class="btn btn-sm btn-primary" data-toggle="modal" data-target=".bd-example-modal-lg_form"><i class="fa fa-plus"></i><span class="btn-icon-add" data-bs-toggle="modal"></span>Emargency Leave</a>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="example3" class="display" style="min-width: 845px">
                            <thead>
                                <tr>
                                    <th></th>
                                    <th>Employee Name</th>
                                    <th>Employee Code</th>
                                    <th>Email</th>
                                    <th>Number</th>
                                    <th class="text-right pr-4">Details</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $employee; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="sorting_1"><img class="rounded-circle" src="<?php echo e(asset('public')); ?>/images/profile/<?php echo e($row->profile_photo_path); ?>" width="35" height="35" alt=""></td>
                                    <td><?php echo e($row->name); ?></td>
                                    <td><?php echo e($row->employee_code); ?></td>
                                    <td><?php echo e($row->email); ?></td>
                                    <td><?php echo e($row->contact_number); ?></td>
                                    <td class="d-flex justify-content-end">
                                        <button class="btn btn-sm btn-success p-1 px-2 view_report" data-toggle="modal" data-id="<?php echo e($row->id); ?>" data-target=".bd-example-modal-lg"><i class="fa fa-folder-open"></i><span class="btn-icon-add"></span>View</button>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    

     <!-- Modal Start-->
     <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Leave Application Details</h5>
                    <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                </div>
                <div class="modal-body pt-2">
                    <table class="table table-bordered table-responsive-sm leaves-table">
                        <div id="target-element"></div>
                    </table>
                </div>
            </div>
        </div>
    </div>
    
    <?php $__env->startPush('script'); ?>
        <script>
            $(document).ready(function(){
                //---Save Data
                var form = '#add-user-form';
                $(form).on('submit', function(event){
                    event.preventDefault();

                    var url = $(this).attr('data-action');
                    var src = $('#redirect').attr('redirect-action');
                    $.ajax({
                        url: url,
                        method: 'POST',
                        data: new FormData(this),
                        dataType: 'JSON',
                        contentType: false,
                        cache: false,
                        processData: false,
                        success:function(response)
                        {
                            $(form).trigger("reset");
                            // alert(response.success);
                            // window.location.href = src;
                            // setTimeout(function() {
                            //     window.location.reload();
                            // }, 1000);
                            swal("Success Message Title", "Well done, you pressed a button", "success")
                            $('.bd-example-modal-lg_form').modal('hide');

                            //---Add Table Row
                            var row = '<tr id="row_todo_'+ response.id + '">';
                            row += '<td>' + response.name + '</td>';
                            row += '<td>' + response.leave_name + '</td>';
                            row += '<td>' + response.formattedDate1 + '</td>';
                            row += '<td>' + response.formattedDate2 + '</td>';
                            row += '<td>' + response.duration + '</td>';
                            row += '<td class="d-flex justify-content-end"> <?php if('+response.status == 0 +'): ?> <span class="badge light badge-warning"><i class="fa fa-circle text-warning mr-1"></i>Pending</span> <?php elseif('+ response.qualification == 1+'): ?> <span class="badge light badge-success"><i class="fa fa-circle text-success mr-1"></i>Successful</span> <?php elseif('+ response.qualification == 2+'): ?> <span class="badge light badge-danger"><i class="fa fa-circle text-danger mr-1"></i>Canceled</span> <?php endif; ?>' + '</td>';
                            
                            if($("#id").val()){
                                $("#row_todo_" + response.id).replaceWith(row);
                            }else{
                                $("#list_todo").prepend(row);
                            }
                            $("#form_todo").trigger('reset');
                            $("#leave_application_list").load(" #leave_application_list");
                        },
                        error: function (xhr) {
                            var errors = xhr.responseJSON.errors;
                            var errorHtml = '';
                            $.each(errors, function(key, value) {
                                errorHtml += '<li style="color:red">' + value + '</li>';
                            });
                            Swal.fire({
                                icon: 'error',
                                title: 'Required data missing?',
                                html: '<ul>' + errorHtml + '</ul>',
                            });
                        }
                    });
                });
            });

            $(document).ready(function(){
                $.ajaxSetup({
                    headers:{
                        'x-csrf-token' : $('meta[name="csrf-token"]').attr('content')
                    }
                });
            });
        </script>
        <script>
            //----Current Date
            var d = new Date()
            var yr =d.getFullYear();
            var month = d.getMonth()+1
            if(month<10){month='0'+month}
            var date =d.getDate();
            if(date<10){date='0'+date}
            var c_date = yr+"-"+month+"-"+date;
            document.getElementById('start_date').value = c_date;
            document.getElementById('end_date').value = c_date;
        </script>
    <?php $__env->stopPush(); ?>
    
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<script>
    //Employee Name click show Code
    $('#employeeName').change(function(){
        var userId = $(this).val();
        $.ajax({
            url:'<?php echo e(route('get_employee_code')); ?>',
            method:'GET',
            dataType:"JSON",
            data:{userId},
            success:function(response){
                $('#employeeCode').html(response.employee_code);
            }
        });
    });
    //get Leave Details
    $(document).ready(function() {
        $('.table-responsive').on('click','.view_report',function(){
            let userId = $(this).data('id');
            $.ajax({
                url:'<?php echo e(route('get_emargency_leave_repot')); ?>',
                method:'GET',
                data:{userId:userId},
                success:function(response){
                    $('#target-element').html(response);
                }
            });
        });
    });
</script>

<?php /**PATH C:\xampp\htdocs\gulf_erp\resources\views/layouts/pages/admin/leave/emargency_leave.blade.php ENDPATH**/ ?>