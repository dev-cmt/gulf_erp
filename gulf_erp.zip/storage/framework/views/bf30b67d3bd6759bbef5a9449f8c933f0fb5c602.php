<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Attendance List<span class="bg-blue-500 text-info rounded px-1 text-xs py-0.5">(<?php echo e($user->name ?? ''); ?>)</span></h4>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Role create')): ?>                    
                    <a href="<?php echo e(route('attendance.export')); ?>" class="btn btn-primary btn-xs py-1 my-1"><i class="fa fa-download"></i><span class="btn-icon-add"></span>Download</a>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <!-- Add your HTML markup here -->
                    
                    <a href="<?php echo e(url('get-procedure')); ?>" class="btn btn-primary btn-xs">Store Procedure</a>
                    <div class="table-responsive">
                        
                        
                    </div>
                </div>

            </div>
        </div>
    </div>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<script>
    $(document).ready(function() {
        // Function to trigger the AJAX request
        function filterData(month) {
            
            alert(month);
            $.ajax({
                url: "<?php echo e(route('filter.attendance')); ?>",
                method: 'POST',
                data: { month: month },
                success: function(response) {
                    alert('hi')
                    // Update the data container with the filtered data
                    $('#data-container').html(response);
                },
                error: function(xhr, status, error) {
                    console.log(error);
                    alert('fail')
                }
            });
        }

        // Handle the change event of the month filter
        $('#month-filter').on('change', function() {
            var selectedMonth = $(this).val();
            filterData(selectedMonth);
        });
    });
</script>

<?php /**PATH C:\xampp\htdocs\gulf_erp\resources\views/layouts/pages/admin/attendance/show.blade.php ENDPATH**/ ?>