<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Department List<span class="bg-blue-500 text-white rounded px-1 text-xs py-0.5"></span></h4>
                    
                    <a href="<?php echo e(route('mast_department.create')); ?>" class="btn btn-sm btn-primary"><i class="fa fa-plus"></i><span class="btn-icon-add"></span>Create</a>
                    
                </div>
                <div class="card-body"> 
                    <p class="text-center text-success"><?php echo e(Session::has('message') ? Session::get('message') : ''); ?></p>
                    <div class="table-responsive">
                        <table id="example3" class="display" style="min-width: 845px">
                            <thead>
                                <tr>
                                    <th>SL No</th>
                                    <th>Department name</th>
                                    <th>Department head</th>
                                    <th>description</th>
                                    <th>status</th>
                                    <th class="text-right pr-4">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                             
                              <?php $__currentLoopData = $department; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>										
                                    <td><?php echo e($data->dept_name); ?></td>
                                    <td><?php echo e($data->user->name); ?></td>
                                    <td><?php echo e($data->description); ?></td>										
                                    <td><?php echo e($data->status == 1 ? 'Active' : 'Inactive'); ?></td>																			
                                    <td class="float-right" style="width:100px">                                
                                        <a href="<?php echo e(route('mast_department.edit', $data->id)); ?>" class="btn btn-success btn-sm btn-xm p-2">Edit</a>
                                        <a href="<?php echo e(route('mast_department.show', $data->id)); ?>" class="btn btn-info btn-sm btn-xm p-2">View</a>                                                             
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\gulf_erp\resources\views/layouts/pages/master/department/index.blade.php ENDPATH**/ ?>