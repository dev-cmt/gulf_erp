<table class="table table-bordered table-responsive-sm" style="min-width: 500px">
    <div class="d-flex justify-content-between">
        <div>
            
        </div>
        
    </div>
    <thead>
        <tr>
            <th>Employee Name</th>
            <th>Leave Type</th>
            <th>Start Date</th>
            <th>End Date</th>
            <th>Duration</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($row->user->name); ?></td>
                <td><?php echo e($row->mastLeave->leave_name); ?></td>
                <td><?php echo e($row->start_date); ?></td>
                <td><?php echo e($row->end_date); ?></td>
                <td><?php echo e($row->duration); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\xampp\htdocs\gulf_erp\resources\views/layouts/pages/admin/leave/leave-details-view.blade.php ENDPATH**/ ?>