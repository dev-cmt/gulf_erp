<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="row mb-4">
        <div class="col-lg-12">
            <a href="<?php echo e(url()->previous()); ?>" class="btn btn-sm btn-primary float-right"><i class="fa fa-reply"></i><span class="btn-icon-add"></span>Back</a>
        </div>
    </div>
    <?php $__currentLoopData = $data->groupBy(function($item) {return $item->created_at->format('Y-m-d');}); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date => $groupedData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Purchase Recived (<span class="text-info"><?php echo e(date("j F, Y", strtotime($date))); ?></span>)</h4>
                    <a href="<?php echo e(route('parsial-purchase-recived.download', ['data' => $date, 'id' => $purchase->id])); ?>" class="btn btn-sm btn-secondary p-1 px-2">
                        <i class="fa fa-print"></i><span class="btn-icon-add"></span>Print
                    </a>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-4 col-sm-12">
                            <div class="row">
                                <label class="col-6 col-form-label"><strong> Invoice No :</strong></label>
                                <label class="col-6 col-form-label"><?php echo e($purchase->inv_no); ?></label>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-12">
                            <div class="row">
                                <label class="col-6 col-form-label"><strong>Invoice Date :</strong></label>
                                <label class="col-6 col-form-label"><?php echo e(date("j F, Y", strtotime($purchase->inv_date))); ?></label>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-12">
                            <div class="row">
                                <label class="col-6 col-form-label"><strong>Supplier Name :</strong></label>
                                <label class="col-6 col-form-label"><?php echo e($purchase->mastSupplier->supplier_name); ?></label>
                            </div>
                        </div>
                    </div>
                    <br>
                    <div class="table-responsive">
                        <table id="items-table" class="table table-bordered">
                            <thead class="thead-light">
                            <tr>
                                <th>SL#</th>
                                <th>Serial No</th>
                                <th>Category</th>
                                <th>Group Name</th>
                                <th>Part No.</th>
                                <th>Date</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $groupedData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(++$key); ?></td>
                                    <td><?php echo e($row->serial_no); ?></td>
                                    <td><?php echo e($row->cat_name); ?></td>
                                    <td><?php echo e($row->part_name); ?></td>
                                    <td><?php echo e($row->part_no); ?></td>
                                    <td><?php echo e($row->created_at); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>

<?php /**PATH D:\xampp\htdocs\gulf_erp\resources\views/layouts/pages/inventory/purchase_receive/parsial-purchase-receive.blade.php ENDPATH**/ ?>