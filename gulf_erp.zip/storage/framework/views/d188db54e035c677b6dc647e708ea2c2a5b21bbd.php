<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <!-- card header -->
                <div class="card-header">
                    <h4 class="card-title">Item Register</h4>
                    <a href="<?php echo e(route('mast_item_register.index')); ?>" class="btn btn-sm btn-primary"><i class="fa fa-reply"></i><span class="btn-icon-add"></span>Back</a>
                </div>
                <!-- card body -->
                <div class="card-body">
                    <div class="form-validation">
                        <!-- this is for validation checking message -->
                        <?php if(session()->has('success')): ?>
                            <strong class="text-success"><?php echo e(session()->get('success')); ?></strong>
                        <?php endif; ?>
                        <!-- this is from -->
                        <form class="form-valide mr-3" action="<?php echo e(route('mast_item_register.store')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="row">
                                            <label for="" class="col-md-4 col-form-label">Item Category
                                                <span class="text-danger">*</span>
                                            </label>
                                            <div class="col-md-8">
                                                <select class="form-control dropdwon_select" name="mast_item_category_id" id="itemCategory" required>
                                                    <option value="" selected disabled>-- Select Category --</option>
                                                    <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($row->id); ?>"><?php echo e($row->cat_name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="row">
                                            <label for="" class="col-md-4 col-form-label">Part Name
                                                <span class="text-danger">*</span>
                                            </label>
                                            <div class="col-md-8">
                                                <select class="form-control dropdwon_select" id="itemGroup" name="mast_item_group_id" required></select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6 ac">
                                    <div class="form-group">
                                        <div class="row">
                                            <label for="" class="col-md-4 col-form-label">Ton/Capacities</label>
                                            <div class="col-md-8">
                                                <select class="form-control dropdwon_select" name="mast_item_models_id" id="loadTon"></select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="row">
                                            <label for="" class="col-md-4 col-form-label">Unit
                                                <span class="text-danger">*</span>
                                            </label>
                                            <div class="col-md-8">
                                                <select class="form-control dropdwon_select" id="loadUnit" name="unit_id" required></select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6 unitSH" style="display: none">
                                    <div class="form-group">
                                        <div class="row">
                                            <label for="" class="col-md-4 col-form-label">Type (Optional)
                                                <span class="text-danger">*</span>
                                            </label>
                                            <div class="col-md-8">
                                                <select class="form-control dropdwon_select" name="unit_type" id="unitType">
                                                    <option value="" selected>-- Select --</option>
                                                    <option value="1">Indoor</option>
                                                    <option value="2">Outdoor</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="row">
                                            <label for="" class="col-md-4 col-form-label model_name">Model Number
                                                <span class="text-danger">*</span>
                                            </label>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control" id="partNo" disabled>
                                                <input type="text" class="form-control <?php $__errorArgs = ['part_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="part_no" id="part_no" value="<?php echo e(old('part_no')); ?>" style="display: none">
                                                <?php $__errorArgs = ['part_no'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="row">
                                            <label for="" class="col-md-4 col-form-label">Quantity
                                                <span class="text-danger">*</span>
                                            </label>
                                            <div class="col-md-8">
                                                <input type="number" class="form-control <?php $__errorArgs = ['box_qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="box_qty" id="box_qty" value="<?php echo e(old('box_qty')); ?>">
                                                <?php $__errorArgs = ['box_qty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6 none_ac" style="display: none">
                                    <div class="form-group">
                                        <div class="row">
                                            <label for="" class="col-md-4 col-form-label">Box Code
                                                <span class="text-danger">*</span>
                                            </label>
                                            <div class="col-md-8">
                                                <input type="number" class="form-control  <?php $__errorArgs = ['box_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="box_code" id="box_code" value="<?php echo e(old('box_code')); ?>" min="1">
                                                <?php $__errorArgs = ['box_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6 none_ac" style="display: none">
                                    <div class="form-group">
                                        <div class="row">
                                            <label for="" class="col-md-4 col-form-label">Gulf Code
                                                <span class="text-danger">*</span>
                                            </label>
                                            <div class="col-md-8">
                                                <input type="text" class="form-control <?php $__errorArgs = ['gulf_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="gulf_code" id="gulf_code" value="<?php echo e(old('gulf_code')); ?>" min="1">
                                                <?php $__errorArgs = ['gulf_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="row">
                                            <label for="" class="col-md-4 col-form-label">Price
                                                <span class="text-danger">*</span>
                                            </label>
                                            <div class="col-md-8">
                                                <input type="number" class="form-control <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="price" id="price" value="<?php echo e(old('price')); ?>" step="any" required>
                                                <?php $__errorArgs = ['price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="row">
                                            <label class="col-md-4 col-form-label">Warranty
                                                <span class="text-danger">*</span>
                                            </label>
                                            <div class="col-md-8">
                                                <select name="warranty" class="form-control default-select <?php $__errorArgs = ['warranty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                                    <option selected disabled>Choose...</option>
                                                    <option value="1" <?php echo e(old('warranty') == '1' ? 'selected' : ''); ?>>One Month</option>
                                                    <option value="2" <?php echo e(old('warranty') == '2' ? 'selected' : ''); ?>>Two Month</option>
                                                    <option value="3" <?php echo e(old('warranty') == '3' ? 'selected' : ''); ?>>Three Month</option>
                                                    <option value="6" <?php echo e(old('warranty') == '6' ? 'selected' : ''); ?>>Six Month</option>
                                                    <option value="12" <?php echo e(old('warranty') == '12' ? 'selected' : ''); ?>>1 Year</option>
                                                    <option value="24" <?php echo e(old('warranty') == '24' ? 'selected' : ''); ?>>2 Years</option>
                                                    <option value="36" <?php echo e(old('warranty') == '36' ? 'selected' : ''); ?>>3 Years</option>
                                                    <option value="48" <?php echo e(old('warranty') == '48' ? 'selected' : ''); ?>>4 Years</option>
                                                    <option value="60" <?php echo e(old('warranty') == '60' ? 'selected' : ''); ?>>5 Years</option>
                                                    <option value="72" <?php echo e(old('warranty') == '72' ? 'selected' : ''); ?>>6 Years</option>
                                                    <option value="84" <?php echo e(old('warranty') == '84' ? 'selected' : ''); ?>>7 Years</option>
                                                    <option value="96" <?php echo e(old('warranty') == '96' ? 'selected' : ''); ?>>8 Years</option>
                                                    <option value="108" <?php echo e(old('warranty') == '108' ? 'selected' : ''); ?>>9 Years</option>
                                                    <option value="120" <?php echo e(old('warranty') == '120' ? 'selected' : ''); ?>>10 Years</option>
                                                </select>

                                                <?php $__errorArgs = ['warranty'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6 none_ac" style="display: none">
                                    <div class="form-group">
                                        <div class="row">
                                            <label for="image" class="col-md-4 col-form-label">Image</label>
                                            <div class="col-md-8">
                                                <input type="file" name="image" class="form-controlf <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" alt="" accept=".jpg, .jpeg, .png, .gif">
                                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <div class="row">
                                            <label for="" class="col-md-4 col-form-label">Description</label>
                                            <div class="col-md-8">
                                                <textarea name="description" class="text form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="1"><?php echo e(old('description')); ?></textarea>
                                                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="invalid-feedback" role="alert">
                                                    <strong><?php echo e($message); ?></strong>
                                                </span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <!-- Submit Button -->
                            <div class="row">
                                <div class="col-md-12">
                                    <button type="submit" class="btn btn-success btn-sm float-right">Submit</button>
                                </div>
                            </div>

                        <form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->startPush('script'); ?>
    <script type="text/javascript">
        $(document).on('change','#itemCategory',function () {
            var itemCategory = $(this).val();
            $.ajax({
                url:'<?php echo e(route('get-part-name')); ?>',
                method:'GET',
                dataType:"html",
                data:{'id': itemCategory},
                success: function(data){
                    $('#itemGroup').html(data);
                }
            });
            if(itemCategory==1){
                $('.ac').show();
                $('.none_ac').hide();
                $('#partNo').show();
                $('#part_no').hide();
                $('.model_name').text("Model Number");
            }else{
                $('.ac').hide();
                $('.none_ac').show();
                $('#partNo').hide();
                $('#part_no').show();
                $('.model_name').text("Part Number");
            }
        });
        $(document).on('change', '#itemGroup', function () {
            var itemCategory = $('#itemCategory').val();
            var id = $(this).val();
            // Send an AJAX request to the server to get data
            $.ajax({
                url: '<?php echo e(route('get-unit-name')); ?>',
                method: 'GET',
                dataType: 'json',
                data: { 'mast_item_category_id': itemCategory, 'mast_item_group_id': id },
                success: function (data) {
                    // SET TON
                    var loadTonSelect = $('#loadTon');
                    loadTonSelect.empty();
                    loadTonSelect.append('<option value="" selected disabled>-- Select --</option>');

                    $.each(data.mastItemModels, function (index, row) {
                        loadTonSelect.append('<option value="' + row.id + '">' + row.ton + '</option>');
                    });
                    
                    // SET UNIT
                    var loadUnitSelect = $('#loadUnit');
                    loadUnitSelect.empty();

                    $.each(data.mstUnit, function (index, row) {
                        var selected = (row.id == '<?php echo e(old('mast_item_group_id')); ?>') ? 'selected' : '';
                        loadUnitSelect.append('<option value="' + row.id + '" ' + selected + '>' + row.unit_name + '</option>');
                    });
                    
                },
                error: function () {
                    alert('Fail');
                }
            });
        });



        $(document).on('change','#loadTon',function () {
            var id = $(this).val();
            getItemModels(id);
        });
        $(document).on('change','#loadUnit',function () {
            var id = $(this).val();
            if(id == 1){//Unit -> 1 => Set
                var loadTon = $('#loadTon').val();
                getItemModels(loadTon);
                $('.unitSH').hide();
                // $('#unitType').prop("disabled", true);
            }else if(id == 2){// Unit -> 2 => Pices
                $('#part_no').val('');
                $('#partNo').val('');
                $('.unitSH').show();
                // $('#unitType').prop("disabled", false);
            }
        });
        $(document).on('change','#unitType',function () {
            var loadTon = $('#loadTon').val();
            getItemModels(loadTon);
        });

        function getItemModels(id){
            $.ajax({
                url: '<?php echo e(route('get-item-models')); ?>',
                method: 'GET',
                dataType: 'JSON',
                data: { 'id': id },
                success: function(data) {
                    var unit_id = $('#loadUnit').val();
                    if(unit_id == 1){
                        $('#partNo').val(data.full_set);
                        $('#part_no').val(data.full_set);
                    }else{
                        $('#part_no').val('');

                        var unitType = $('#unitType').val();
                        if(unitType == 1){
                            $('#partNo').val(data.indoor);
                            $('#part_no').val(data.indoor);
                        }else if(unitType == 2){
                            $('#partNo').val(data.outdoor);
                            $('#part_no').val(data.outdoor);
                        }else{
                            $('#part_no').val('');
                        }
                    } 
                },
                error: function() {
                    alert('Fail');
                }
            });
        }

        //----Validation
        $(document).ready(function() {
            const inputBC = $("#box_code");
            const inputGC = $("#gulf_code");
            // const inputPO = $("#part_no");
            const inputBQ = $("#box_qty");
            const inputPC = $("#price");
            
            const maskBC = new IMask(inputBC[0], { mask: "000000000" });
            const maskGC = new IMask(inputGC[0], { mask: "000000000" });
            // const maskPO = new IMask(inputPO[0], { mask: "000000000" });
            const maskBQ = new IMask(inputBQ[0], { mask: "000000000" });
            const maskPC = new IMask(inputPC[0], { mask: "000000000" });
            
            // You can access unmasked values like this:
            // const unmaskedBC = maskBC.unmaskedValue;
            // const unmaskedGC = maskGC.unmaskedValue;
            // const unmaskedPO = maskPO.unmaskedValue;
            // const unmaskedBQ = maskBQ.unmaskedValue;
            // const unmaskedPC = maskPC.unmaskedValue;
        });
    </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH D:\xampp\htdocs\gulf_erp\resources\views/layouts/pages/master/item_register/create.blade.php ENDPATH**/ ?>