<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Stock Position</h4>
                    <div>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Role create')): ?>
                            <a href="#" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#exampleModalCenter"><i class="fa fa-search"></i><span class="btn-icon-add" data-bs-toggle="modal"></span>Tracking </a>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="card-body">
                    
                    



                    <table class="table table-bordered table-responsive-sm" style="min-width: 500px">
                        <thead>
                            <tr>
                                <th>SL#</th>
                                <th>Group Name</th>
                                <th>Part No.</th>
                                <th>Stock Qty</th>
                                <th>Sales Price</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $countItem = DB::table('sl_movements')
                                    ->where('mast_item_register_id', $row->id)
                                    ->whereIn('reference_type_id', [1, 3])
                                    ->where('mast_work_station_id', 1)
                                    ->where('status', 1)
                                    ->count();
                                ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($row->part_name); ?></td>
                                    <td><?php echo e($row->part_no); ?></td>
                                    <td><?php echo e($countItem); ?></td>
                                    <td><?php echo e($row->price); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>


    <!-- Tracing Item -->
    <div class="modal fade" id="exampleModalCenter">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <form class="form-valide" data-action="<?php echo e(route('setup-attendance-store')); ?>" method="POST" enctype="multipart/form-data" id="add-user-attendacne-id">
                    <?php echo csrf_field(); ?>
                    <div class="modal-header">
                        <h5 class="modal-title">Tracing Item</h5>
                        <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                    </div>
                    <div class="modal-body">
                        <div class="d-flex justify-content-between">
                            <input type="text" name="serial_no" id="serialNo" class="form-control mr-2" value="" placeholder="Enter Serial No.">

                            <button id="reset" class="btn btn-sm btn-secondary">Find</button>
                        </div>
                    </div>
                    <div class="modal-footer">

                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php $__env->startPush('script'); ?>

    <script>
        $(document).ready(function(){
            fetch();
        });

        // Fetch records
        function fetch(user_id, start_date, end_date) {
            $.ajax({
                url: "<?php echo e(route('get-attendance-filter')); ?>",
                method:'GET',
                dataType:"html",
                data: {
                    user_id: user_id,
                    start_date: start_date,
                    end_date: end_date
                },
                success:function(data){
                    $('#attendance-list').html(data);
                },
                error: function(xhr, status, error) {
                    swal("Error!", "Failed to fetch data!", "error");
                }
            });
        }
        // Filter
        $('#filter-data').on('input change', '#start_date, #end_date, #user_id', function() {
            var user_id = $("#user_id").val();
            var start_date = $("#start_date").val();
            var end_date = $("#end_date").val();

            fetch(user_id, start_date, end_date);
        });
        // Reset
        var clearDropdownHtml = $('#user_id').html();
        var startDate = $('#start_date').val();
        var endDate = $('#end_date').val();
        $(document).on("click", "#reset", function(e) {
            e.preventDefault();
            $('#user_id').html(clearDropdownHtml);
            $('#start_date').val(startDate);
            $('#end_date').val(endDate);
            fetch();
        });
    </script>

    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH D:\xampp\htdocs\gulf_erp\resources\views/layouts/pages/inventory/stock_position/index.blade.php ENDPATH**/ ?>