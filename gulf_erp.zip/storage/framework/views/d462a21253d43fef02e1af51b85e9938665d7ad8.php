<table class="table table-bordered table-responsive-sm" style="min-width: 500px">
    <div class="d-flex justify-content-between">
        <div>
            <span class="mr-2" style="font-weight: 700;margin:20px 0px">Employee Name :</span><label class="col-form-label"><?php echo e($user->name); ?></label>
        </div>
        <a href="<?php echo e(route('attendance.export')); ?>" class="btn btn-primary btn-xs py-1 my-1"><i class="fa fa-download"></i><span class="btn-icon-add"></span>Download</a>
    </div>
    <thead>
        <tr>
            <th>SL NO</th>
            <th>Date</th>
            <th>In time</th>
            <th>Out time</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($row->date); ?></td>
                <td><?php echo e($row->in_time); ?></td>
                <td><?php echo e($row->out_time); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\xampp\htdocs\gulf_erp\resources\views/layouts/pages/admin/attendance/attendance-details-view.blade.php ENDPATH**/ ?>