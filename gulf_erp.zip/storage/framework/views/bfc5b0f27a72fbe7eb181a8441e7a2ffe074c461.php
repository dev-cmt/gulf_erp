<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" zoom="0.8">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=0.9">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('public/backend')); ?>/images/favicon.png">
    <!-- Custom Stylesheet -->
	<link href="<?php echo e(asset('public/backend')); ?>/vendor/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('public/backend')); ?>/css/style.css" rel="stylesheet">
    
    <!-- Jquery -->
    <script src="<?php echo e(asset('public/backend')); ?>/js/jquery-3.5.1.min.js"></script>
</head>
<body>
    <?php echo e($slot); ?>

</body>
</html><?php /**PATH D:\xampp\htdocs\gulf_erp\resources\views/layouts/reports.blade.php ENDPATH**/ ?>