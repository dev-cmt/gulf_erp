<table class="table table-bordered table-responsive-sm" style="min-width: 500px">
    <thead>
        <tr>
            <th>SL#</th>
            <th>Employee ID</th>
            <th>Username</th>
            <th>Day</th>
            <th>Date</th>
            <th>In time</th>
            <th>Out time</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($row->employee_code); ?></td>
                <td><?php echo e($row->name); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($row->date)->format('D')); ?></td>
                <td><?php echo e($row->date); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($row->in_time)->format('g:i A')); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($row->out_time)->format('g:i A')); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<div class="dataTables_info">Showing <?php echo e(count($data)); ?> entries</div>
<?php /**PATH C:\xampp\htdocs\gulf_erp\resources\views/layouts/pages/admin/attendance/load-attendance-list.blade.php ENDPATH**/ ?>