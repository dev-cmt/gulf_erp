<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="row">

        <div class="col-12">

            <div class="card">

                <!-- card header -->
                <div class="card-header">
                    <h4 class="card-title">
                        <?php if($type == 1): ?>
                            Distributor Create
                            <?php elseif($type == 2): ?>
                            Corporate Create
                            <?php else: ?>
                            Retailer Create

                        <?php endif; ?>
                    </h4>
                    <a href="#" class="btn btn-sm btn-primary"><i class="fa fa-reply"></i><span class="btn-icon-add"></span>Back</a>
                </div>
                <!-- card body -->
                <div class="card-body">

                    <div class="form-validation">
                        <form class="form-valide mt-0" action="<?php echo e(route('get.distributor.store')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="cat_id" value="<?php echo e($type); ?>">
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="row mt-1">
                                        <label for="" class="col-md-4 col-form-label">
                                            <?php if($type == 1): ?>
                                                Distributor Name
                                                <?php elseif($type == 2): ?>
                                                Corporate Name
                                                <?php else: ?>
                                                Retailer Name

                                            <?php endif; ?>
                                            <span class="text-danger">*</span>
                                        </label>
                                        <div class="col-md-8">
                                            <input type="text" id="" class="form-control" name="dist_name" placeholder="Enter Distributor Name" value="" >
                                            <?php $__errorArgs = ['dist_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($errors->first('dist_name')); ?></span>
                                         <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="row mt-1">
                                        <label class=" col-md-4 col-form-label">phone
                                            <span class="text-danger">*</span>
                                        </label>
                                        <div class="col-md-8">
                                            <input type="text" id="" class="form-control" name="phone" value="">

                                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                    <div class="row mt-1">
                                        <label for="" class="col-md-4 col-form-label">Contact person
                                            <span class="text-danger"></span>
                                        </label>
                                        <div class="col-md-8">
                                            <input type="text" id="" class="form-control" name="con_person" placeholder="Enter contact person" value="" >
                                            <?php $__errorArgs = ['location'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($errors->first('location')); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="row mt-1">
                                        <label for="" class="col-md-4 col-form-label">Mobile
                                            <span class="text-danger"></span>
                                        </label>
                                        <div class="col-md-8">
                                            <input type="number" id="" class="form-control" name="con_mobile" placeholder="Enter mobile number" value="" >
                                            
                                        </div>
                                    </div>
                                    <div class="row mt-1">
                                        <label for="" class="col-md-4 col-form-label">Web Url
                                         <span class="text-danger"></span>

                                        </label>
                                        <div class="col-md-8">
                                         <input type="text" id="" class="form-control" name="web_address" placeholder="Enter web address" value="">
                                         

                                         <?php $__errorArgs = ['start_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                 <span class="text-danger"><?php echo e($errors->first('start_time')); ?></span>
                                             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                     </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="row mt-1">
                                        <label for="" class="col-md-4 col-form-label">Email
                                            <span class="text-danger">*</span>
                                        </label>
                                        <div class="col-md-8">
                                            <input type="email" id="" class="form-control " name="email" placeholder="Enter your email" value="">
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                                        </div>
                                    </div>
                                    <div class="row mt-1">
                                        <label for="" class="col-md-4 col-form-label">Address
                                            <span class="text-danger">*</span>
                                        </label>
                                        <div class="col-md-8">
                                            <input type="text" id="" class="form-control" name="address" placeholder="Enter a address" value="">
                                            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($errors->first('address')); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="row mt-1">
                                        <label for="" class="col-md-4 col-form-label">Designation
                                            <span class="text-danger"></span>
                                        </label>
                                        <div class="col-md-8">
                                            <input type="text" id="" class="form-control" name="designation" placeholder="Enter a designation" value="">
                                            <?php $__errorArgs = ['attendance_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="text-danger"><?php echo e($errors->first('attendance_type')); ?></span>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="row mt-1">
                                        <label for="" class="col-md-4 col-form-label">Email
                                            <span class="text-danger"></span>
                                        </label>
                                        <div class="col-md-8">
                                            <input type="email" id="" class="form-control " name="con_email" placeholder="Enter your contact email" value="">

                                            <?php $__errorArgs = ['emp_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="row mt-1">
                                        <label for="" class="col-md-4 col-form-label">Credit Limit
                                            <span class="text-danger"></span>
                                        </label>
                                        <div class="col-md-8">
                                            <input type="number" id="" class="form-control" name="credit_limit" value="0">

                                            <?php $__errorArgs = ['end_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <span class="text-danger"><?php echo e($errors->first('end_time')); ?></span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="row mt-1">
                                        <label for="" class="col-md-4 col-form-label">
                                            <span class="text-danger"></span>
                                        </label>
                                        <div class="col-md-8">
                                            <input type="hidden" id="" class=" " name="emp_id" placeholder="" value="1">

                                            <?php $__errorArgs = ['emp_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-md-12">
                                    <div class="row mt-1">
                                        <label for="" class="col-md-2 col-form-label">Remarks:</label>
                                        <div class="col-md-10">
                                            <textarea  id="" cols="30" rows="1" class="form-control" name="remarks" placeholder="Please Write Something..."></textarea>
                                            
                                        </div>
                                    </div>

                                </div>
                                <div class="col-md-12">
                                    <div class="row mt-1">
                                        <label for="" class="col-md-8"></label>
                                        
                                        <button type="submit" class="btn btn-success btn-sm" style="margin-left: 270px">Submit</button>

                                    </div>
                                </div>
                            </div>
                        </form>

                    </div>

                </div>

            </div>

        </div>

    </div>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>


<?php /**PATH C:\xampp\htdocs\gulf_erp\resources\views/layouts/pages/master/distributor/distributor-create.blade.php ENDPATH**/ ?>