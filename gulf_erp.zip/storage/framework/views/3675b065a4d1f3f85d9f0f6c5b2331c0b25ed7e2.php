<table class="table table-bordered table-responsive-sm" style="min-width: 500px">
    <thead>
        <tr>
            <th>SL#</th>
            <th>Day</th>
            <th>Date</th>
            <th>Employee ID</th>
            <th>Username</th>
            <th>In time</th>
            <th>Out time</th>
            <th>Status</th>
            <th>DLE#</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr id="row_<?php echo e($row->id); ?>" class="<?php echo e($row->is_late == 1 ? 'bg-light text-danger': ''); ?><?php echo e(!in_array($row->attendance_type, ['P', 'L']) ? 'bg-light text-info' : ''); ?>">
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($row->date)->format('D')); ?></td>
                <td><?php echo e($row->date); ?></td>
                <td><?php echo e($row->employee_code); ?></td>
                <td><?php echo e($row->name); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($row->in_time)->format('g:i A')); ?></td>
                <td><?php echo e(\Carbon\Carbon::parse($row->out_time)->format('g:i A')); ?></td>
                <td class=""><?php echo e($row->attendance_type); ?></td>
                <td><button id="delete_attendance" data-id="<?php echo e($row->id); ?>" class="btn btn-primary shadow btn-xs sharp"><i class="fa fa-trash"></i></button></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<div class="dataTables_info">Showing <?php echo e(count($data)); ?> entries</div>
<?php /**PATH D:\xampp\htdocs\gulf_erp\resources\views/layouts/pages/admin/attendance/load-attendance-list.blade.php ENDPATH**/ ?>