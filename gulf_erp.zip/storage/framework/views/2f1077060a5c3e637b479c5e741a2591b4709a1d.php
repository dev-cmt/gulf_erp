    <!--**********************************
                Sidebar start
    ***********************************-->
    <div class="deznav scrollbar">
            <div class="main-profile">
                <div class="image-bx">
                    <img src="<?php echo e(asset('public')); ?>/images/profile/<?php echo e(Auth::user()->profile_photo_path); ?>" alt="">
                    <a href="javascript:void(0);"><i class="fa fa-cog" aria-hidden="true"></i></a>
                </div>
                <h5 class="name"><?php echo e(Auth::user()->name); ?></h5>
                <p class="email"><a href="mailto:<nowiki><?php echo e(Auth::user()->email); ?>">[<?php echo e(Auth::user()->email); ?>]</a></p>
            </div>
            <ul class="metismenu" id="menu">
                <li class="nav-label first">Main Menu</li>
                <li><a href="<?php echo e(route('dashboard')); ?>" class="ai-icon" aria-expanded="false">
                        <i class="flaticon-144-layout"></i>
                        <span class="nav-text">Dashboard</span>
                    </a>
                </li>
                

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['Super-Admin', 'Admin', 'Inventory access'])): ?>
                <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
                        <i class="flaticon-381-home"></i>
                        <span class="nav-text">Inventory</span>
                    </a>
                    <ul aria-expanded="false">
                        <li><a href="<?php echo e(route('grn-purchase.index')); ?>">GRN (Warehouse)</a></li>
                        <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">Purchase</a>
                            <ul aria-expanded="false">
                                
                                <li><a href="<?php echo e(route('inv_purchase.index',['cat_id' => 3])); ?>">Car Spare Parts</a></li>
                                <li><a href="<?php echo e(route('inv_purchase_approve.create')); ?>">Approve Purchase </a></li>
                            </ul>
                        </li>
                        <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">Store Transfer</a>
                            <ul aria-expanded="false">
                                
                                <li><a href="<?php echo e(route('store_transfer.index',['cat_id' => 3])); ?>">Car Spare Parts</a></li>
                                <li><a href="<?php echo e(route('store_transfer_approve.create')); ?>">Requisition Approve </a></li>
                            </ul>
                        </li>
                        <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">Delivery</a>
                            <ul aria-expanded="false">
                                <li><a href="<?php echo e(route('sales-delivery.index')); ?>">Sales Delivery</a></li>
                                <li><a href="<?php echo e(route('store-delivery.index')); ?>">Store Delivery</a></li>
                            </ul>
                        </li>
                        <!-- <li><a href="#">Stock Update</a></li> -->
                        <li><a href="<?php echo e(route('stock-position.index')); ?>">Stock Position</a></li>
                        <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">Reports</a>
                            <ul aria-expanded="false">
                                <li><a href="<?php echo e(route('parsial-purchase-details')); ?>">Purchase Received</a></li>
                                <li><a href="<?php echo e(route('parsial-sales-details')); ?>">Sales Delivery</a></li>
                                <li><a href="<?php echo e(route('parsial-store-delivery')); ?>">Store Delivery</a></li>
                            </ul>
                        </li>
                        <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">Data Setting</a>
                            <ul aria-expanded="false">
                                <li><a href="<?php echo e(route('mast_supplier.index')); ?>">Supplier List</a></li>
                                <li><a href="<?php echo e(route('mast_item_category.index')); ?>">Item Category</a></li>
                                <li><a href="<?php echo e(route('mast_item_group.index')); ?>">Item Group</a></li>
                                <li><a href="<?php echo e(route('mast_unit.index')); ?>">Units Setting</a></li>
                                
                                <li><a href="<?php echo e(route('mast_item_register.index')); ?>">Item Register</a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['Super-Admin', 'Admin', 'Sales access'])): ?>
                <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
                        <i class="flaticon-381-layer-1"></i>
                        <span class="nav-text">Sales</span>
                    </a>
                    <ul aria-expanded="false">
                        <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">Sales Quotation</a>
                            <ul aria-expanded="false">
                                
                                <li><a href="<?php echo e(route('sales_quotation.index',['cat_id' => 3])); ?>">Car Spare Parts</a></li>
                                <li><a href="<?php echo e(route('sales_quotation_approve.index')); ?>">Approve Quotation </a></li>
                            </ul>
                        </li>
                        <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">Sales</a>
                            <ul aria-expanded="false">
                                
                                <li><a href="<?php echo e(route('sales.index',['cat_id' => 3])); ?>">Car Spare Parts</a></li>
                                <li><a href="<?php echo e(route('sales_approve.create')); ?>">Approve Sales </a></li>
                            </ul>
                        </li>
                        <li><a href="<?php echo e(route('sales-return.index')); ?>">Sales Return</a></li>
                        <li><a href="<?php echo e(route('sales-receive.index')); ?>">Return Receive</a></li>
                        <li><a href="#">Reports</a></li>
                        <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">Data Setting</a>
                            <ul aria-expanded="false">
                                <li><a href="<?php echo e(route('customer.index',['cat_id' => 1])); ?>">Corporate Details</a></li>
                                <li><a href="<?php echo e(route('customer.index',['cat_id' => 2])); ?>">Distributer Details</a></li>
                                <li><a href="<?php echo e(route('customer.index',['cat_id' => 3])); ?>">Retailer Details</a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['Super-Admin', 'Admin', 'Warrenty access'])): ?>
                <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
                        <i class="flaticon-149-diagram"></i>
                        <span class="nav-text">Warrenty & Service</span>
                    </a>
                    <ul aria-expanded="false">
                        <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">Complaint & Issue</a>
                            <ul aria-expanded="false">
                                <li><a href="<?php echo e(route('warranty-complaint.index')); ?>">Complaint List</a></li>
                                <li><a href="<?php echo e(route('warranty-customer-list.show')); ?>">New Complaint</a></li>

                            </ul>
                        </li>
                        <li><a href="<?php echo e(route('warranty-prepare-card.index')); ?>">Prepare Job Card</a></li>
                        <li><a href="<?php echo e(route('warranty-movement.index')); ?>">Tachnician Movement</a></li>
                        <li><a href="<?php echo e(route('item-requisition.index')); ?>">Item Requsition</a></li>
                        <li><a href="<?php echo e(route('service-bill.index')); ?>">Service Bill</a></li>
                        <li><a class="has-arrow" href="javascript:void()" aria-expanded="false">Data Setting</a>
                            <ul aria-expanded="false">
                                <li><a href="<?php echo e(route('tecnician.index')); ?>">Info. Technician</a></li>
                                <li><a href="<?php echo e(route('mast_compliant_type.index')); ?>">Compliant Type</a></li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('Super-Admin', 'User access','User create','User edit','User delete', 'Role access', 'Role create','Role edit','Role delete')): ?>
                <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
                        <i class="flaticon-381-settings-2"></i>
                        <span class="nav-text">Setting</span>
                    </a>
                    <ul aria-expanded="false">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('Role access', 'Role create','Role edit','Role delete')): ?>
                            <li><a href="<?php echo e(route('roles.index')); ?>">Manage Role</a></li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any('User access','User create','User edit','User delete')): ?>
                        <li><a href="<?php echo e(Route('users.index')); ?>">Manage User</a></li>
                        <?php endif; ?>
                    </ul>
                </li>
                <?php endif; ?>
            </ul>
            <div class="copyright">
                
                <div class="image-bx apps_install">
                    <a href="<?php echo e(asset('public/gulf.apk')); ?>"><img src="<?php echo e(asset('public')); ?>/images/icon-android.png" style="width:60%;" alt=""></a>
                </div>
                <p><strong>Gulf ERP Admin Dashboard</strong> © 2023 All Rights Reserved</p>
                <p class="fs-12">Made with <span class="heart"></span> by ICON ISL</p>
            </div>
    </div>
    <!--**********************************
                Sidebar end
    ***********************************-->
<?php /**PATH D:\xampp\htdocs\gulf_erp\resources\views/layouts/partial/sidebar.blade.php ENDPATH**/ ?>