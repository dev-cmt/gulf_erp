<!DOCTYPE html>
<html lang="en">
<head>
    <title>Item Export</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
         table {
        width: 100%;
        border-collapse: collapse;
        }
        
        th, td {
            padding: 8px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        th {
            background-color: #f2f2f2;
        }
        
        tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }
    </style>
</head>
<body>           
    <table class="table table-hover">
        <thead>
            <colgroup>
                <col width="5%">
                <col width="15%">
                <col width="10%">
                <col width="10%">
                <col width="15%">
                <col width="10%">
                <col width="10%">
                <col width="10%">
                <col width="10%">
                <col width="10%">
            </colgroup>
            <tr>
                <th scope="col" style="width: 5px">#</th>
                <th scope="col">Image</th>
                <th scope="col">Box No.</th>
                <th scope="col" style="width: 75px">Gulf Code</th>
                <th scope="col" style="width: 90px">Part No.</th>
                <th scope="col">Part Name</th>
                <th scope="col" style="width: 90px">Description</th>
                <th scope="col" style="width: 80px">Box Qty.</th>
                <th scope="col">Pirce</th>
                <th scope="col">Bare Code</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>										
                    <td class="sorting_1"><img src="<?php echo e(asset('public')); ?>/images/car-parts/<?php echo e($row->image); ?>" width="40" height="40" alt=""></td>
                    <td><?php echo e($row->box_code); ?></td>
                    <td><?php echo e($row->gulf_code); ?></td>
                    <td><?php echo e($row->part_no); ?></td>
                    <td><?php echo e($row->mastItemGroup->part_name ?? 'N/A'); ?></td>
                    <td><?php echo e($row->description); ?></td>
                    <td><?php echo e($row->box_qty); ?></td>
                    <td><?php echo e($row->price); ?></td>
                    <td><?php echo DNS1D::getBarcodeHTML("$row->bar_code", 'PHARMA'); ?> GULF-<?php echo e($row->bar_code); ?> </td>
                    
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        </tbody>
    </table>
    </div>

</body>
</html>

<?php /**PATH /home/iconislcombd/erp.iconisl.com.bd/resources/views/layouts/pages/export/mast_item.blade.php ENDPATH**/ ?>