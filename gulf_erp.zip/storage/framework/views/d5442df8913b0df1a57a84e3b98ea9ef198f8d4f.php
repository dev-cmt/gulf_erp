<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Sales Delivery List</h4>
                </div>

                <div class="card-body">
                    <div class="table-responsive">
                        <table id="example3" class="display " style="min-width: 845px">
                            <thead>
                                <tr>
                                    <th>SL#</th>
                                    <th>Invoice No</th>
                                    <th>Invoice Date</th>
                                    <th>Customer Name</th>
                                    <th>Type</th>
                                    <th>Item</th>
                                    
                                    <th>Total</th>
                                    <th>Status</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                            <tbody id="sales_tbody">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $total = 0;
                                    $qty = 0;
                                    $item = 0;
                                    foreach ($row->salesDetails as $key => $value) {
                                        $total += $value->qty * $value->price;
                                        $qty += $value->qty;
                                        $item += 1;
                                    }
                                ?>
                                <tr id="row_sales_table_<?php echo e($row->id); ?>">
                                    <td><?php echo e(++$key); ?></td>
                                    <td><?php echo e($row->inv_no); ?></td>
                                    <td><?php echo e($row->inv_date); ?></td>
                                    <td><?php echo e($row->mastCustomer->name ?? 'NULL'); ?></td>
                                    <td><?php echo e($row->mastItemCategory->cat_name ?? 'NULL'); ?></td>
                                    <td id="details_data" data-id="<?php echo e($row->id); ?>"><span style="cursor: pointer" class="badge badge-pill badge-success badge-rounded"><?php echo e($item); ?></span></td>
                                    
                                    <td><?php echo e($total); ?></td>
                                    <td>
                                        <?php if($row->is_parsial == 1): ?>  
                                        <span class="badge light badge-warning">
                                            <i class="fa fa-circle text-warning mr-1"></i>Parsial
                                        </span>
                                        <?php elseif($row->is_parsial == 0): ?>
                                        <span class="badge light badge-success">
                                            <i class="fa fa-circle text-success mr-1"></i>Complete
                                        </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-right">
                                        <a href="<?php echo e(route('sales-delivery-details-parsial', $row->id)); ?>" class="btn btn-sm btn-info p-1 px-2"><i class="fa fa-info"></i></i><span class="btn-icon-add"></span>Details</a>
                                        <a href="<?php echo e(route('sales-delivery.download', $row->id)); ?>" class="btn btn-sm btn-secondary p-1 px-2"><i class="fa fa-print"></i></i><span class="btn-icon-add"></span>Print</a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!--============//Show Modal Data//================-->
                <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-hidden="true">
                    <div class="modal-dialog modal-xl">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Sales Details</h5>
                                <button type="button" class="close" data-dismiss="modal"><span>&times;</span></button>
                            </div>
                            <div class="card-body pt-2">
                                <div class="row">
                                    <div class="col-md-3 col-sm-12 pr-0">
                                        <div class="row">
                                            <label class="col-5 col-form-label"><strong> Invoice No :</strong></label>
                                            <label class="col-7 col-form-label" id="inv_no"></label>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12 px-0">
                                        <div class="row">
                                            <label class="col-6 col-form-label"><strong>Invoice Date :</strong></label>
                                            <label class="col-6 col-form-label" id="inv_date"></label>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12 px-0">
                                        <div class="row">
                                            <label class="col-6 col-form-label"><strong>Customer Name :</strong></label>
                                            <label class="col-6 col-form-label" id="mast_customers"></label>
                                        </div>
                                    </div>
                                    <div class="col-md-3 col-sm-12 pl-0">
                                        <div class="row">
                                            <label class="col-5 col-form-label"><strong>Store Name :</strong></label>
                                            <label class="col-7 col-form-label" id="store_name"></label>
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <div class="table-responsive">
                                    <table id="items-table" class="table table-bordered mb-0">
                                        <thead>
                                            <tr>
                                                <th>SL#</th>
                                                <th>Category</th>
                                                <th>Group Name</th>
                                                <th>Part No.</th>
                                                <th>Price</th>
                                                <th>Qty</th>
                                                <th>Sub Total</th>
                                            </tr>
                                        </thead>
                                        <tbody id="table-body"></tbody>
                                    </table>
                                </div>
                                <div class="row">
                                    <div class="col-md-12 pt-4">
                                        <div class="float-right">
                                            <h6>Total <span style="border: 1px solid #2222;padding: 10px 40px;margin-left:10px" id="total">0.00</span></h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<script>
    /*=======//View Details Add Modal//=========*/
    $(document).on('click', '#details_data', function() {
    var id = $(this).data('id');
    $('#table-body').empty();
        $.ajax({
            url: '<?php echo e(route('get_sales_approve_details')); ?>',
            method: 'GET',
            dataType: "JSON",
            data: {'id': id},
            success: function(response) {
                var dataMast = response.sales;

                $('#inv_no').html(dataMast.inv_no);
                $("#inv_date").html(dataMast.inv_date);
                $("#mast_customers").html(dataMast.name);
                $("#store_name").html(response.store);
                $('#remarks').html(response.remarks);

                var dataDetails = response.data;
                var total = 0; // Variable to hold the total value
                $.each(dataDetails, function(index, item) {
                    var subtotal = item.qty * item.price;
                    var row = '<tr id="row_todo_'+ item.id + '">';
                    row += '<td>' + (index + 1) + '</td>'; // Add SL# column
                    row += '<td>' + item.cat_name + '</td>'; // Add Category column
                    row += '<td>' + item.part_name + '</td>'; // Add Group Name column
                    row += '<td>' + item.part_no + '</td>';
                    row += '<td>' + item.price + '</td>';
                    row += '<td>' + item.qty + '</td>';
                    row += '<td>' + subtotal + '</td>';
                    row += '</tr>';
                    $('#table-body').append(row);

                    total += subtotal;
                });
                // Update the total value in the HTML
                $('#total').html(total.toFixed(2));
            },
            error: function(response) {
                swal("Error!", "All input values are not null or empty.", "error");
            }
        });
        $(".bd-example-modal-lg").modal('show');
    });
</script><?php /**PATH D:\xampp\htdocs\gulf_erp\resources\views/layouts/pages/inventory/reports/sales-delivery.blade.php ENDPATH**/ ?>