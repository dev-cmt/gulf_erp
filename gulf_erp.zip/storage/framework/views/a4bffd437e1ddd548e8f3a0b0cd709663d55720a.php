
<option disabled selected>--Select--</option>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($row->id); ?>"><?php echo e($row->serial_no); ?></option>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\xampp\htdocs\gulf_erp\resources\views/layouts/pages/inventory/sales_delivery/load-serial-number.blade.php ENDPATH**/ ?>